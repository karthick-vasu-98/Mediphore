from rest_framework import status, permissions, generics
from rest_framework.views import APIView
from .import api


class TagView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, *args, **kwargs):
        message = None
        try:
            result, msg, data = api.get_tag_list(request)
            if result:
                message = api.HTTP_REST_MESSAGES['200']
                return api.build_response(status.HTTP_200_OK, message, data=data, errors=dict())
            else:
                return api.build_response(status.HTTP_400_BAD_REQUEST, message, data=data, errors=dict())
        except Exception as e:
            print('Exception :', e)
            message = api.HTTP_REST_MESSAGES['500']
            return api.build_response(status.HTTP_500_INTERNAL_SERVER_ERROR, message, data=dict(), errors=dict())
        
    def post(self, request, code=None, mode=None, *args, **kwargs):
        result = False
        message = None
        try:
            if code and mode:
                result, msg, data = api.update_tag(request, code, mode)
            else:
                result, msg, data = api.create_tag(request)

            if result:
                message = msg
                return api.build_response(status.HTTP_200_OK, message, data={}, errors=dict())
            else:
                return api.build_response(status.HTTP_400_BAD_REQUEST, message, data=data, errors=dict())
        except Exception as e:
            print('Exception :', e)
            message = api.HTTP_REST_MESSAGES['500']
            return api.build_response(status.HTTP_500_INTERNAL_SERVER_ERROR, message, data=dict(), errors=dict())



class FileView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, *args, **kwargs):
        message = None
        try:
            result, msg, data = api.get_file_list(request)
            if result:
                message = api.HTTP_REST_MESSAGES['200']
                return api.build_response(status.HTTP_200_OK, message, data=data, errors=dict())
            else:
                return api.build_response(status.HTTP_400_BAD_REQUEST, message, data=data, errors=dict())
        except Exception as e:
            print('Exception :', e)
            message = api.HTTP_REST_MESSAGES['500']
            return api.build_response(status.HTTP_500_INTERNAL_SERVER_ERROR, message, data=dict(), errors=dict())
        
    def post(self, request, code=None, mode=None, *args, **kwargs):
        result = False
        message = None
        try:
            if code and mode:
                result, msg, data = api.update_file(request, code, mode)
            else:
                result, msg, data = api.create_file(request)

            if result:
                message = msg
                return api.build_response(status.HTTP_200_OK, message, data={}, errors=dict())
            else:
                return api.build_response(status.HTTP_400_BAD_REQUEST, message, data=data, errors=dict())
        except Exception as e:
            print('Exception :', e)
            message = api.HTTP_REST_MESSAGES['500']
            return api.build_response(status.HTTP_500_INTERNAL_SERVER_ERROR, message, data=dict(), errors=dict())



class TagBasedFileView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request, *args, **kwargs):
        result = False
        message = None
        try:
            result, msg, data = api.get_tag_based_file_list(request)
            if result:
                message = api.HTTP_REST_MESSAGES['200']
                return api.build_response(status.HTTP_200_OK, message, data=data, errors=dict())
            else:
                return api.build_response(status.HTTP_400_BAD_REQUEST, message, data=data, errors=dict())
        except Exception as e:
            print('Exception :', e)
            message = api.HTTP_REST_MESSAGES['500']
            return api.build_response(status.HTTP_500_INTERNAL_SERVER_ERROR, message, data=dict(), errors=dict())
