from django.db import models

DATAMODE = (('A', 'A'), ('I', 'I'), ('D', 'D'))
STORAGE_TYPE = (('LOCAL', 'LOCAL'), ('CLOUD', 'CLOUD'))
FILE_STORAGE_FOLDER = 'UploadedFiles'


class Tag(models.Model):
    name = models.CharField(max_length=255, null=True, blank=True, db_index=True, unique=True)
    code = models.CharField(max_length=128, null=True, blank=True, db_index=True, unique=True)
    created_on = models.DateTimeField(auto_now_add=True)
    updated_on = models.DateTimeField(auto_now=True)
    datamode = models.CharField(max_length=8, null=True, blank=True, default='A', choices=DATAMODE)

    def save(self, *args, **kwargs):
        super(Tag, self).save(*args, **kwargs)
        if not(self.code):
            self.code = "TAG-%04d" % (int(self.id))
            super(Tag, self).save()

    def __str__(self):
        return "{0}-({1})".format(self.name, self.code)
    

class FileData(models.Model):
    code = models.CharField(max_length=255, null=True, blank=True, unique=True, db_index=True)
    name = models.CharField(max_length=255, null=True, blank=True)
    tags = models.TextField(blank=True, null=True)
    storage_type = models.CharField(max_length=255, null=True, blank=True, choices=STORAGE_TYPE)
    file = models.FileField(null=True, blank=True, upload_to=FILE_STORAGE_FOLDER)
    file_url = models.CharField(max_length=255, null=True, blank=True)
    created_on = models.DateTimeField(null=True, blank=True, auto_now_add=True)
    updated_on = models.DateTimeField(null=True, blank=True, auto_now=True)
    datamode = models.CharField(max_length=8, null=True, blank=True, default='A', choices=DATAMODE)

    def save(self, *args, **kwargs):
        super(FileData, self).save(*args, **kwargs)
        if not(self.code):
            self.code = "UPLOADED-FILE-%04d" % (int(self.id))
            super(FileData, self).save()

    def __str__(self):
        return "{0}-({1})".format(self.name, self.code)

