from django.urls import path
from . import views as app_views

urlpatterns = [
    #TAG CRUD
    path('tag-list/', app_views.TagView.as_view(), name='tag_list'),
    path('tag-create/', app_views.TagView.as_view(), name='tag_create'),
    path('tag-update/<code>/<mode>/', app_views.TagView.as_view(), name='tag_update'),

    #FILE CRUD
    path('file-list/', app_views.FileView.as_view(), name='file_list'),
    path('file-create/', app_views.FileView.as_view(), name='file_create'),
    path('file-update/<code>/<mode>/', app_views.FileView.as_view(), name='file_update'),

    path('tag-based-file-list/', app_views.TagBasedFileView.as_view(), name='tag_based_file_list'),
]