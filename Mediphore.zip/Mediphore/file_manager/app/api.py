import sys
import json
import datetime
from zoneinfo import ZoneInfo
from rest_framework.response import Response
from django.utils.translation import gettext_lazy as _
from file_manager import settings
from .import models as app_models
from .import serializers as app_serializers

HTTP_REST_MESSAGES = {"200": _("Success"),
                      "400": _("Failed"),
                      "401": _("Authentication Failed"),
                      "500": _("Internal server error")}


def build_response(status, message, data=dict(), errors=dict()):
    try:
        return Response({'status_code': status, 'message': message, 'data':data,'errors': errors}, status=status)
    except Exception as e:
        print('Exception :', e)


def convert_date_time_format(date_time, tz_offset=0, date_format=None):
    if date_time:
        if not date_format:
            date_format = settings.DEFAULT_DATE_TIME_FORMAT

        if isinstance(date_time, str):
            date_time = date_time(tz=ZoneInfo('Asia/Kolkata'))
            date_time = datetime.datetime.strptime(date_time, '%Y-%m-%d %H:%M:%S.%f')
        date_time = date_time + datetime.timedelta(hours=5, minutes=30)
        return date_time.strftime("{}".format(settings.DEFAULT_DATE_TIME_FORMAT))
    else:
        return ""


def get_tag_list(request):
    result = False
    msg = 'Error'
    data = dict()
    try:
        tag_list = app_models.Tag.objects.filter(datamode='A')
        serializer = app_serializers.TagListSerializer(tag_list, many=True)
        result, msg, data = True, 'Success', serializer.data
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Error  :', (exc_traceback.tb_lineno, e))
    return result, msg, data


def create_tag(request):
    result = False
    msg = 'Error'
    data = dict()
    try:
        pDict = request.POST.copy()
        serializer = app_serializers.TagCreateUpdateSerializer(data=pDict)
        if serializer.is_valid():
            serializer.save()
            result, msg = True, 'Tag Created Successfully'
        else:
            data = serializer.errors
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Error  :', (exc_traceback.tb_lineno, e))
    return result, msg, data


def update_tag(request, code, mode):
    result = False
    msg = 'Error'
    data = dict()
    try:
        if mode == 'edit':
            tag = app_models.Tag.objects.filter(code=code, datamode='A').first()
            if tag:
                pDict = request.POST.copy()
                serializer = app_serializers.TagCreateUpdateSerializer(instance=tag, data=pDict)
                if serializer.is_valid():
                    serializer.save()
                    result, msg = True, 'Tag Updated Successfully'
                else:
                    data = serializer.errors
        elif mode == 'delete':
            tag = app_models.Tag.objects.filter(code=code, datamode='A').first()
            if tag:
                tag.datamode = 'D'
                tag.save()
                result, msg = True, 'Tag Deleted Successfully'
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Error  :', (exc_traceback.tb_lineno, e))
    return result, msg, data


def get_file_list(request):
    result = False
    msg = 'Error'
    data = dict()
    try:
        file_list = app_models.FileData.objects.filter(datamode='A')
        serializer = app_serializers.FileListSerializer(file_list, many=True)
        result, msg, data = True, 'Success', serializer.data
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Error  :', (exc_traceback.tb_lineno, e))
        msg = e
    return result, msg, data


def create_file(request):
    result = False
    msg = 'Error'
    data = dict()
    try:
        pDict = request.POST.copy()
        fDict = request.FILES.copy()
            
        serializer = app_serializers.FileCreateUpdateSerializer(data=pDict)
        if serializer.is_valid():
            if pDict.get('storage_type') and pDict.get('storage_type') == 'CLOUD':
                pass
            else:
                obj = serializer.save()
                file_data = app_models.FileData.objects.filter(id=obj.id, datamode='A').first()
                if file_data:
                    file_data.file = fDict.get('file')
                    file_data.save()
                    result, msg = True, 'File Created Successfully'
        else:
            data = serializer.errors
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Error  :', (exc_traceback.tb_lineno, e))
    return result, msg, data


def update_file(request, code, mode):
    result = False
    msg = 'Error'
    data = dict()
    try:
        if mode == 'edit':
            file = app_models.FileData.objects.filter(code=code, datamode='A').first()
            if file:
                pDict = request.POST.copy()
                fDict = request.FILES.copy()
                serializer = app_serializers.FileCreateUpdateSerializer(instance=file, data=pDict)
                if serializer.is_valid():
                    serializer.save()
                    if pDict.get('storage_type') and pDict.get('storage_type') == 'CLOUD':
                        pass
                    else:
                        if fDict and fDict.get('file'):
                            file.file = fDict.get('file')
                            file.save()
                            result, msg = True, 'File Updated Successfully'
                        else:
                            result, msg = True, 'File Updated Successfully'
                else:
                    data = serializer.errors
        elif mode == 'delete':
            file = app_models.FileData.objects.filter(code=code, datamode='A').first()
            if file:
                file.datamode = 'D'
                file.save()
                result, msg = True, 'File Deleted Successfully'
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Error  :', (exc_traceback.tb_lineno, e))
    return result, msg, data


def get_tag_based_file_list(request):
    result = False
    msg = 'Error'
    data = dict()
    try:
        pDict = request.POST.copy()
        tags = list()
        if pDict.get('tags'):
            tags = list(pDict.get('tags').split(","))
            tags = [x.strip(" ") for x in tags]
            file_list = app_models.FileData.objects.filter(datamode='A')
            files = list()
            for file in file_list:
                if len(set(json.loads(file.tags)).intersection(set(tags))) > 0:
                    files.append(file)
            serializer = app_serializers.TagBasedFileListSerializer(files, many=True)
            for item in serializer.data:
                item.update({'rank':len(set(item['tag_list']) & set(tags)) / float(len(set(item['tag_list']) | set(tags))) * 100})
            result, msg, data = True, 'Success', sorted(serializer.data, key=lambda x:x['rank'], reverse=True)
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Error  :', (exc_traceback.tb_lineno, e))
        msg = e
    return result, msg, data