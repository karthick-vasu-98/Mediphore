import json
from file_manager import settings
from rest_framework import serializers
from .import models as app_models
from .import api


class TagListSerializer(serializers.ModelSerializer):
    used_in = serializers.SerializerMethodField(read_only=True)
    created_on = serializers.SerializerMethodField(read_only=True)
    updated_on = serializers.SerializerMethodField(read_only=True)

    def get_used_in(self, data):
        count = 0
        files = app_models.FileData.objects.filter(datamode='A')
        for file in files:
            if data.code in file.tags:
                count += 1
        if count > 1:
            used_in = "{0} Files".format(count)
        else:
            used_in = "{0} File".format(count)
        return used_in
    
    def get_created_on(self, data):
        return api.convert_date_time_format(data.created_on)

    def get_updated_on(self, data):
        return api.convert_date_time_format(data.updated_on)

    class Meta:
        model = app_models.Tag
        fields = ['id', 'code', 'name', 'used_in', 'created_on', 'updated_on']


class TagCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = app_models.Tag
        exclude = ['code']


class FileListSerializer(serializers.ModelSerializer):
    file_url = serializers.SerializerMethodField(read_only=True)
    tag_list = serializers.SerializerMethodField(read_only=True)
    created_on = serializers.SerializerMethodField(read_only=True)
    updated_on = serializers.SerializerMethodField(read_only=True)
    
    def get_tag_list(self, data):
        tags = json.loads(data.tags)
        tags = app_models.Tag.objects.filter(code__in=tags, datamode='A')
        tag_list = TagListSerializer(tags, many=True).data
        return tag_list

    def get_file_url(self, data):
        if data.storage_type == 'CLOUD':
            file_url = data.file_url
        else:
            file_url = settings.APP_URL+settings.MEDIA_URL + str(data.file)
        return file_url

    def get_created_on(self, data):
        return api.convert_date_time_format(data.created_on)

    def get_updated_on(self, data):
        return api.convert_date_time_format(data.updated_on)

    class Meta:
        model = app_models.FileData
        fields = ['id', 'code', 'name', 'tag_list', 'file_url', 'created_on', 'updated_on']


class FileCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = app_models.FileData
        exclude = ['code']


class TagBasedFileListSerializer(serializers.ModelSerializer):
    # rank = serializers.SerializerMethodField(read_only=True)
    file_url = serializers.SerializerMethodField(read_only=True)
    tag_list = serializers.SerializerMethodField(read_only=True)
    created_on = serializers.SerializerMethodField(read_only=True)
    updated_on = serializers.SerializerMethodField(read_only=True)
    
    def get_tag_list(self, data):
        tags = json.loads(data.tags)
        return tags
    
    # def get_rank(self, data):
    #     request = self.context['request']
    #     print('request :', request)
    #     pDict = request.POST.copy()
    #     if pDict.getlist('tags'):
    #         tags = pDict.getlist('tags')
    #     res = len(set(json.loads(data.tags)) & set(tags)) / float(len(set(json.loads(data.tags)) | set(tags))) * 100
    #     return res

    def get_file_url(self, data):
        if data.storage_type == 'CLOUD':
            file_url = data.file_url
        else:
            file_url = settings.APP_URL+settings.MEDIA_URL + str(data.file)
        return file_url

    def get_created_on(self, data):
        return api.convert_date_time_format(data.created_on)

    def get_updated_on(self, data):
        return api.convert_date_time_format(data.updated_on)

    class Meta:
        model = app_models.FileData
        fields = ['id', 'code', 'name', 'tag_list', 'file_url', 'created_on', 'updated_on']